import SwiftUI

struct ContentView: View {
    @State private var showingScore = false
    @State private var showingtitle = ""
    @State var score = 0
    @State var maxScore = 0
    @State var flagtrack = ""
    @State var isGameActive = true
    @State var isWinner = false
    @State var playerName = UserDefaults.standard.string(forKey: "playerName") ?? "Player"
    @State private var newHighScoreName = ""
    @State private var showNamePrompt = false
    @State private var countries = ["Afghanistan","Albania","Algeria","Andorra","Angola","Anguilla","Antigua and Barbuda","Argentina","Armenia","Aruba","Australia","Austria","Azerbaijan","Bahamas","Bahrain","Bangladesh","Barbados","Belarus","Belgium","Belize","Benin","Bermuda","Bhutan","Bolivia","Bosnia & Herzegovina","Botswana","Brazil","Virgin Islands British","Brunei","Bulgaria","Burkina Faso","Burundi","Cambodia","Cameroon","Cape Verde","Cayman Islands","Chad","Chile","China","Colombia","Congo","Cook Islands","Costa Rica","Cote D Ivoire","Croatia","Cuba","Cyprus","Czech Republic","Denmark","Djibouti","Dominica","Ecuador","Egypt","El Salvador","Equatorial Guinea","Estonia","Ethiopia","Falkland Islands","Faroe Islands","Fiji","Finland","France","French Polynesia","French West Indies","French Guiana","Gabon","Gambia","Georgia","Germany","Ghana","Gibraltar","Greece","Greenland","Grenada","Guam","Guatemala","Guernsey","Guinea","Guinea Bissau","Guyana","Haiti","Honduras","Hong Kong","Hungary","Iceland","BHARAT","Indonesia","Iran","Iraq","Ireland","Isle of Man","Israel","Italy","Jamaica","Japan","Jersey","Jordan","Kazakhstan","Kenya","Kuwait","Kyrgyzstan","Laos","Latvia","Lebanon","Lesotho","Liberia","Libya","Liechtenstein","Lithuania","Luxembourg","Macau","Macedonia","Madagascar","Malawi","Malaysia","Maldives","Mali","Malta","Mauritania","Mauritius","Mexico","Moldova","Monaco","Mongolia","Montenegro","Montserrat","Morocco","Mozambique","Namibia","Nepal","Netherlands","New Caledonia","New Zealand","Nicaragua","Niger","Nigeria","Norway","Oman","Pakistan","Palestine","Panama","Papua New Guinea","Paraguay","Peru","Philippines","Poland","Portugal","Puerto Rico","Qatar","Reunion","Romania","Russia","Rwanda","Saint Pierre & Miquelon","Samoa","San Marino","Saudi Arabia","Senegal","Serbia","Seychelles","Sierra Leone","Singapore","Slovakia","Slovenia","South Africa","South Korea","Spain","Sri Lanka","St Kitts & Nevis","St Lucia","St Vincent","Sudan","Suriname","Swaziland","Sweden","Switzerland","Syrian Arab Republic","Taiwan","Tajikistan","Tanzania","Thailand","Timor L'Este","Togo","Tonga","Trinidad & Tobago","Tunisia","Turkey","Turkmenistan","Turks & Caicos","Uganda","Ukraine","United Arab Emirates","United Kingdom","Uruguay","Uzbekistan","Venezuela","Vietnam","Virgin Island (US)","Virgin Island British","Yemen","Zambia","Zimbabwe"].shuffled()
    @State private var correctAnswer = Int.random(in: 0...2)
    @State var lives = 5
    @State var gameOver = false
    
    var body: some View {
        ZStack{
            RadialGradient(stops: [
                .init(color: Color(red:0.26,green: 0.2,blue:0.45), location: 0.6),
                .init(color: Color(red: 0.26, green: 0.7, blue: 0.98), location: 0.3)
            ],center: .top,startRadius: 200,endRadius: 400).ignoresSafeArea()
            VStack{
                Text("Guess The Flag")
                    .font(.largeTitle.weight(.bold))
                    .foregroundColor(.white)
                VStack(spacing:20){
                    VStack(){
                        Text("Tap the flag of")
                            .font(.subheadline.weight(.heavy))
                            .foregroundStyle(.secondary)
                        Text(countries[correctAnswer])
                            .font(.largeTitle.weight(.semibold))
                    }
                    ForEach(0..<3){ number in
                        Button(){
                            flagTapped(number)
                            flagtrack = countries[number]
                        }label: {
                            Image(countries[number])
                                .resizable()
                                .shadow(radius: 15)
                        }.padding(.horizontal)
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .padding(.vertical, 20)
                .background(.regularMaterial)
                .clipShape(.rect(cornerRadius: 20))
                Spacer()
                Spacer()
                HStack{
                    Spacer()
                    VStack{
                        Text("Life")
                        Text("\(lives)")
                    } .font(.title.bold())
                      .foregroundStyle(.white)
                    Spacer()
                    VStack{
                        Text("Score")
                        Text("\(score)")
                    } .font(.title.bold())
                      .foregroundStyle(.white)
                    Spacer()
                    VStack{
                        Text("Highest")
                        Text(" \(maxScore)")
                    } .font(.title.bold())
                      .foregroundStyle(.white)
                    Spacer()
                }
            }.padding()
            .alert(showingtitle, isPresented: $showingScore) {
                Button("Continue", action: askQuestion)
            } message: {
                showingtitle == "Wrong" ? Text("Wrong! It's a flag of \(flagtrack) score: \(score)") : Text("Whoaa🎉 Score: \(score)")
            }
            .alert("GAME OVER!🥺", isPresented: $gameOver) {
                Button("Restart", role: .destructive, action: restart)
            } message: {
                Text("You are out of life")
            }
            .alert("New High Score!🎉", isPresented: $showNamePrompt) {
                TextField("Enter your name", text: $newHighScoreName)
                Button("OK", action: saveHighScore)
            } message: {
                Text("You broke the previous record!")
            }
        }
        .onAppear(perform: loadGameData) // Load saved game data when the app starts
    }
    
    func flagTapped(_ number: Int) {
        if number == correctAnswer {
            showingtitle = "Correct"
            if lives > 0 {
                score += 1
                if score > maxScore {
                    maxScore = score
                    showNamePrompt = true // Show name prompt when a new high score is reached
                }
                saveGameData() // Save score and max score
            }
        } else {
            if lives >= 0 {
                lives -= 1
            }
            showingtitle = "Wrong"
        }
        showingScore = true
    }
    
    func askQuestion() {
        if lives <= 0 {
            gameOver = true
            saveGameData() // Save when game is over
        } else {
            countries.shuffle()
            correctAnswer = Int.random(in: 0...2)
        }
    }
    
    func restart() {
        lives = 5
        score = 0
        countries.shuffle()
        correctAnswer = Int.random(in: 0...2)
        saveGameData() // Save reset game state
    }
    
    // Save player name, score, and highest score
    func saveGameData() {
        UserDefaults.standard.set(playerName, forKey: "playerName")
        UserDefaults.standard.set(score, forKey: "playerScore")
        UserDefaults.standard.set(maxScore, forKey: "maxScore")
    }
    
    // Save the new high score and player name
    func saveHighScore() {
        playerName = newHighScoreName.isEmpty ? "Player" : newHighScoreName
        saveGameData()
        newHighScoreName = ""
    }
    
    // Load saved player name, score, and highest score
    func loadGameData() {
        playerName = UserDefaults.standard.string(forKey: "playerName") ?? "Player"
        score = UserDefaults.standard.integer(forKey: "playerScore")
        maxScore = UserDefaults.standard.integer(forKey: "maxScore")
    }
}
#Preview{
    ContentView()
}
