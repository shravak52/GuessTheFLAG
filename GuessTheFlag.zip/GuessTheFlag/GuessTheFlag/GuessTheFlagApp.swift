//
//  GuessTheFlagApp.swift
//  GuessTheFlag
//
//  Created by Shravak Jain on 03/04/24.
//

import SwiftUI

@main
struct GuessTheFlagApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
